// extern function defined in file.cu
extern void welcome();

int main() {
  welcome();
}