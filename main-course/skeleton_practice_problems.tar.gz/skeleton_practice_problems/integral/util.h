#pragma once

double get_current_time();