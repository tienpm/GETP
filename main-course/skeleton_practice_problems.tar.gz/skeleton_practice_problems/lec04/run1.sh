#!/bin/bash

make
./convert int 4155
