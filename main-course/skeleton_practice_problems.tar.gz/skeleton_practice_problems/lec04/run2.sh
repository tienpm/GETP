#!/bin/bash

make
./convert long -550
