#!/bin/bash

make
./convert float 3.1415
