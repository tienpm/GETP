#!/bin/bash

srun --nodes=1 ./main $@
