#include "vec_add.h"

#include <pthread.h>
#include <immintrin.h>
#include <cstdio>
#include <algorithm>

void vec_add(float *_A, float *_B, float *_C, int _M, int _num_threads) {
  // IMPLEMENT HERE
}
