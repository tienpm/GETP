#pragma once

void vec_add(float *_A, float *_B, float *_C, int _M, int _num_threads);
