#pragma once

void vecadd(float *_A, float *_B, float *_C, int N);
void vecadd_init(int N);
void vecadd_cleanup(float *_A, float *_B, float *_C, int N);
